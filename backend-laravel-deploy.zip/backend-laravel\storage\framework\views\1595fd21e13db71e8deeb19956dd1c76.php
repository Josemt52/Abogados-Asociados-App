<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Expediente <?php echo e($expediente->numero); ?></title>
    <style>
        body {
            font-family: Helvetica, Arial, sans-serif;
            margin: 40px;
        }
        h1 {
            font-size: 14pt;
            font-weight: bold;
        }
        .field {
            font-size: 12pt;
            margin-bottom: 15px;
        }
        .estado-section {
            margin-top: 30px;
        }
        .estado-title {
            font-size: 12pt;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .estado-content {
            font-size: 10pt;
            line-height: 1.5;
        }
    </style>
</head>
<body>
    <h1>EXPEDIENTE: <?php echo e($expediente->numero); ?></h1>
    
    <div class="field">MATERIA: <?php echo e($expediente->materia ?? ''); ?></div>
    <div class="field">JUEZ: <?php echo e($expediente->juzgado ?? ''); ?></div>
    <div class="field">ESPECIALISTA: <?php echo e($expediente->especialista ?? ''); ?></div>
    <div class="field">TERCERO: <?php echo e($expediente->tercero ?? ''); ?></div>
    <div class="field">DEMANDADO: <?php echo e($expediente->demandado ?? ''); ?></div>
    <div class="field">DEMANDANTE: <?php echo e($expediente->demandante ?? ''); ?></div>
    
    <div class="estado-section">
        <div class="estado-title">Estado Actual del Expediente:</div>
        <div class="estado-content">
            <?php echo e(strip_tags($expediente->estado ?? '')); ?>

        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\jose\Desktop\Abogados-Asociados-App\backend-laravel\resources\views/pdf/expediente.blade.php ENDPATH**/ ?>